<nav class="navbar navbar-inverse">
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
      <ul class="nav navbar-nav">
       <div class="navbar-header">
       		<a class="navbar-brand" href="?rute=home">STBI</a>
       </div>

<!-- |  <li class="active"><a href="index.php?act=nothing">Beranda</a></li> -->
<li><a class="active" href="?rute=koleksi">Dokumen</a></li>
<!-- <li><a href="index.php?act=indexing">Buat Index</a></li> -->
<li><a href="?rute=hitung">Hitung Bobot</a></li>
<!-- <li><a href="index.php?act=panjangvektor">Hitung Panjang Vektor</a></li>
<li><a href="index.php?act=showindex">Tampilkan index</a></li>
<li><a href="index.php?act=showvektor">Tampilkan Panjang Vektor</a></li>
<li><a href="index.php?act=retrieve">Retrieval</a></li> -->
<!-- <li><a href="?rute=cache">Tampilkan Cache</a></li> -->
</div>
  </div>
</nav>