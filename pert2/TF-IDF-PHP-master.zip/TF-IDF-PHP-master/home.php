<div class="container-fluid bg-1 text-center">
     
    </div>
  </br>
    <div class="container-fluid bg-3 text-center">
      <div id="layerl1"></div>
      <div class="col-md-4 ">
                  <div class="panel panel-success">
                      <div class="panel-heading">
                      <h3 class="panel-title">Gontang Ragil Prakasa</h3>
                      </div>
                      <div class="panel-body">
                        
                        <div class="font"><center>
                        <?php
                          echo "1500018280";
                        ?>
                      </center></div>
                  </div>           
              </div>
       
    </div>        
    <div id="layerl2"></div>
    <div class="col-md-4">
                  <div class="panel panel-primary">
                      <div class="panel-heading">
                      <h3 class="panel-title">Arica Putra Subandria</h3>
                      </div>
                      <div class="panel-body">
                        <div class="font"><center>
                        <?php
                         	echo "1500018004";
                        ?>
                      </center></div>
                  </div>             
            </div>     
        </div>
    <div id="layerl3"></div>
    <div class="col-md-4">
                  <div class="panel panel-danger">
                      <div class="panel-heading">
                      <h3 class="panel-title">Marzota Dwi R</h3>
                      </div>
                      <div class="panel-body">
                        <div class="font"><center>
                        <?php
                          echo "15000018003";
                        ?>
                      </center></div>
                  </div>           
            </div>
    </div>
    </div>
