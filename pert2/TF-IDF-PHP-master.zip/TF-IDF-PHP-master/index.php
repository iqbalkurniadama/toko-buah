<!DOCTYPE >
<html>
<head>
	<title></title>
</head>
<body>
	<a href="?rute=koleksi"><center><h1>Tugas Akhir Information Retrieval</h1></center></a>
	<br><br>
	<?php 	
			include "library/import.php";
			include "koneksi.php";
			// include "navbar.php";
			include "fungsi.php";
			include "alur.php";
	?>
</body>
</html>